<?php
    $nome = filter_input(INPUT_GET, "nome");
    $estilo = filter_input(INPUT_GET, "estilo");
    $pais = filter_input(INPUT_GET, "pais");
    $descrição = filter_input(INPUT_GET, "descrição");
    $inicio = filter_input(INPUT_GET, "inicio");
    $fim = filter_input(INPUT_GET, "fim");
    $spotify = filter_input(INPUT_GET, "spotify");
    $link = mysqli_connect("localhost","root","","musicworld");

    if($link){
        $query = mysqli_query($link,"insert into bandas values('','$nome','$estilo','$pais','$descrição','$inicio','$fim','$spotify');");
        if($query){
            header("location:index.php");
        }else{
         die("Erro: ". mysqli_error($link));  
        }
    }else{
        die("Erro: ". mysqli_error($link));
    }
?>