<!DOCTYPE html>
<?php 
error_reporting(0);
ini_set(“display_errors”, 0 );
include ("conexao.php");
session_start();
    ?>
    
    <html>
    <link rel="shortcut icon" type="image/png" href="img/favicon.png"/>
    <title>Music World</title>
    <link href="https://fonts.googleapis.com/css?family=Russo+One" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <style>
        .imglogo{
    margin-top: -87px;
    margin-left: -35px;
    height: 110px;
    width: 340px;    
}
    .divbanda {
    height:100px;
    width:400px;
    border-radius: 6px;
    background-color: rgb(48, 48, 48);
    box-shadow: 1px 1px 5px #000;
}
    .font{
        font-family: 'Russo One';
        color: white;
        font-size: 500%;
        text-shadow: #050505 0 1px 0;
    }

    table{
        margin-left: 10px;
    }
    .link{
        text-decoration:none;
        color:white;
    }
    body {
    background-image: url("img/background.png");
    background-repeat: no-repeat;
    background-position: left top;
    background-attachment: fixed;
    background-size: 99.999%;
}
html, body {
    max-width: 100%;
    overflow-x: hidden;
}
    </style>
         <div class="header" width="100%"><br>
<table border="0px" width="93%" valign="middle">
<th width="35%" align="left">
<th><center><br><br><br><br><img src="img/logo.png" class="imglogo"></center></th>
<th width="20%" align="left">
<th width="15%" align="left"><a href="index.php" style=text-decoration:none;><span style="font-size:40px;cursor:pointer" class="openbtn">Voltar</span></a>&nbsp&nbsp&nbsp
</table>
</div>
         <center><font><br><br>
         <table border="0px" width="100%" valign="middle"><tr>
         <th width="30%"><div class="divbanda font"><a href="exemplo.php" class="link">Banda 1</div>
         <th width="30%"><div class="divbanda font"><a href="exemplo.php" class="link">Banda 2</div>
         <th width="30%"><div class="divbanda font"><a href="exemplo.php" class="link">Banda 3</div><tr height="10px"><tr>
         <th width="30%"><div class="divbanda font"><a href="exemplo.php" class="link">Banda 4</div>
         <th width="30%"><div class="divbanda font"><a href="exemplo.php" class="link">Banda 5</div>
         <th width="30%"><div class="divbanda font"><a href="exemplo.php" class="link">Banda 6</div><tr height="10px"><tr>
         <th width="30%"><div class="divbanda font"><a href="exemplo.php" class="link">Banda 7</div>
         <th width="30%"><div class="divbanda font"><a href="exemplo.php" class="link">Banda 8</div>
         <th width="30%"><div class="divbanda font"><a href="exemplo.php" class="link">Banda 9</div><tr height="10px"><tr>
         <th width="30%"><div class="divbanda font"><a href="exemplo.php" class="link">Banda 10</div>
         <th width="30%"><div class="divbanda font"><a href="exemplo.php" class="link">Banda 11</div>
         <th width="30%"><div class="divbanda font"><a href="exemplo.php" class="link">Banda 12</div>
         </font>